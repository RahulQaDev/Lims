# YLIMS Design System Export

A self-contained bundle of the YLIMS app's design tokens, atom components, utilities, and conventions. Hand this folder to Claude (or any LLM) along with `CLAUDE.md` to build new components / pages that match the YLIMS look and feel.

## What's inside

```
design-system-export/
├── README.md                      ← you are here
├── CLAUDE.md                      ← paste this into Claude as a system prompt
├── design-system-primer.md        ← brand identity + patterns + conventions
├── tailwind-config.md             ← Tailwind v4 setup + brand tokens
├── atoms/                         ← 18 atom components, source as-is
│   ├── Button/Button.tsx
│   ├── Input/Input.tsx
│   ├── Select/Select.tsx
│   ├── Textarea/Textarea.tsx
│   ├── Checkbox/Checkbox.tsx
│   ├── Toggle/Toggle.tsx
│   ├── Label/Label.tsx
│   ├── ErrorMessage/ErrorMessage.tsx
│   ├── Spinner/Spinner.tsx
│   ├── Skeleton/Skeleton.tsx
│   ├── Tooltip/Tooltip.tsx
│   ├── Badge/Badge.tsx
│   ├── Card/Card.tsx
│   ├── Divider/Divider.tsx
│   ├── Text/Text.tsx
│   ├── DateInput/DateInput.tsx    ← uses date-fns + react-day-picker
│   ├── TimeInput/TimeInput.tsx
│   └── LabLoader/LabLoader.tsx    ← branded "scientist" loading animation
├── utils/
│   ├── cn.ts                      ← classnames merger
│   ├── classNames.ts              ← legacy classnames helper
│   ├── date.ts                    ← formatDate / formatDateTime
│   └── formatters.ts              ← formatBytes / formatRelativeTime / formatNumber / formatCurrency
└── examples/                      ← composed patterns Claude can mimic
    ├── slide-over-panel.tsx
    ├── modal-dialog.tsx
    └── form-with-validation.tsx
```

## Stack assumed

| Layer | Version |
|---|---|
| React | 19+ |
| Build tool | Vite (any modern bundler works) |
| Styling | **Tailwind CSS v4** (CSS-first config, see `tailwind-config.md`) |
| Forms | React Hook Form + Zod 4.x |
| Date library | date-fns |
| Icons | @heroicons/react |
| Headless | @radix-ui/react-tooltip, @radix-ui/react-label |
| Calendar | react-day-picker |
| Variants | class-variance-authority |

**Required npm packages** (drop these into the new project):

```json
{
  "dependencies": {
    "react": "^19.0.0",
    "react-dom": "^19.0.0",
    "react-hook-form": "^7.0.0",
    "zod": "^4.0.0",
    "date-fns": "^3.0.0 || ^4.0.0",
    "react-day-picker": "^9.0.0",
    "@heroicons/react": "^2.0.0",
    "@radix-ui/react-tooltip": "^1.0.0",
    "@radix-ui/react-label": "^2.0.0",
    "class-variance-authority": "^0.7.0",
    "clsx": "^2.0.0",
    "tailwind-merge": "^2.0.0"
  }
}
```

## How to use this bundle

1. Copy the `atoms/` and `utils/` folders into your new project (e.g. `src/components/atoms/` and `src/utils/`).
2. Wire the Tailwind CSS-first config from `tailwind-config.md` into your `index.css`.
3. Install the npm dependencies listed above.
4. Open Claude in your editor / chat. Paste **`CLAUDE.md`** as the first message (or as a project-level instruction file).
5. Hand Claude the next message: *"Build me &lt;the thing&gt;. Use the atoms in `src/components/atoms/` and follow the conventions in `design-system-primer.md`."*

Claude will then read the primer + atoms and build new components / pages that match YLIMS visually and behaviourally.

## What this bundle is NOT

- Not a runnable demo — there's no `package.json` or build setup here. It's a parts kit + manual.
- Not a complete component library — only the foundational atoms are included. Heavier components (data grids, slide-overs, complex auto-search selects, rich-text editors) are out of scope; the primer describes the patterns so Claude can build new instances.
- Not exhaustive — patterns Claude needs are in `design-system-primer.md`. If the exec's project needs something domain-specific (e.g. a sample-receipt-style barcode panel), that's where Claude will need extra context from you.

## Updating this bundle

The atoms are copied verbatim from `frontend/src/components/atoms/`. To refresh the bundle after the YLIMS app evolves:

```bash
# from repo root
ATOMS="Button Input Select Textarea Checkbox Toggle Spinner Skeleton Tooltip Badge Label ErrorMessage Card Divider Text DateInput TimeInput LabLoader"
for a in $ATOMS; do
  rm -rf frontend/docs/design-system-export/atoms/$a
  cp -r frontend/src/components/atoms/$a frontend/docs/design-system-export/atoms/$a
done
cp frontend/src/utils/{cn.ts,classNames.ts,date.ts,formatters.ts} frontend/docs/design-system-export/utils/
```

Then re-read the primer + tailwind-config docs and add anything new.

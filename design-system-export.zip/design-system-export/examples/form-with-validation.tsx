/**
 * Form with validation — RHF + Zod + atoms + auto-scroll-to-error.
 *
 * Use this as the canonical RHF setup for any new form in YLIMS style.
 *
 * - One Zod schema for client-side validation.
 * - `Controller` wraps each atom so RHF owns the value and onChange.
 * - On submit fail: toast first error + scroll-to-first-invalid-field + auto-focus.
 * - On submit success: call your service, show success toast, optionally close panel.
 */

import React from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import Input from '@/components/atoms/Input/Input';
import Select from '@/components/atoms/Select/Select';
import Toggle from '@/components/atoms/Toggle/Toggle';
import Textarea from '@/components/atoms/Textarea/Textarea';
import Button from '@/components/atoms/Button/Button';
import Spinner from '@/components/atoms/Spinner/Spinner';
import { useToast } from '@/contexts/ToastContext';

// ── Schema ────────────────────────────────────────────────────────
const schema = z.object({
  name: z.string().min(1, 'Name is required').max(200),
  email: z.string().email('Invalid email'),
  category: z.string().min(1, 'Pick a category'),
  isActive: z.boolean(),
  remarks: z.string().max(500).optional(),
});
type FormData = z.infer<typeof schema>;

// ── Component ─────────────────────────────────────────────────────
export const YourForm: React.FC<{ onSaved: () => void }> = ({ onSaved }) => {
  const { showSuccess, showError } = useToast();

  const {
    control,
    handleSubmit,
    formState: { errors, isSubmitting },
    setFocus,
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { name: '', email: '', category: '', isActive: true, remarks: '' },
  });

  const onSubmit = async (data: FormData) => {
    try {
      await yourService.create(data);
      showSuccess('Saved successfully');
      onSaved();
    } catch (err: any) {
      showError(err.message || 'Failed to save');
    }
  };

  // Called by RHF when submit fails validation. Toasts + scrolls to first error.
  const onInvalid = (errs: typeof errors) => {
    const firstField = Object.keys(errs)[0] as keyof FormData;
    const msg = (errs as any)[firstField]?.message as string;
    if (msg) showError(msg);
    setFocus(firstField);
    setTimeout(() => {
      const el = document.querySelector(`[name="${firstField}"]`) as HTMLElement;
      el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 50);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit, onInvalid)} className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Controller
          name="name"
          control={control}
          render={({ field }) => (
            <Input label="Name *" {...field} error={errors.name?.message} />
          )}
        />
        <Controller
          name="email"
          control={control}
          render={({ field }) => (
            <Input label="Email *" type="email" {...field} error={errors.email?.message} />
          )}
        />
      </div>

      <Controller
        name="category"
        control={control}
        render={({ field }) => (
          <Select
            label="Category *"
            value={field.value}
            onChange={(e) => field.onChange(e.target.value)}
            placeholder="Select category"
            options={[
              { value: 'a', label: 'Category A' },
              { value: 'b', label: 'Category B' },
            ]}
            error={errors.category?.message}
          />
        )}
      />

      <Controller
        name="remarks"
        control={control}
        render={({ field }) => (
          <Textarea label="Remarks" {...field} error={errors.remarks?.message} />
        )}
      />

      {/* Toggle (custom event shape — value/checked) */}
      <div className="flex items-center justify-between p-3.5 rounded-lg border-2 border-gray-200 dark:border-gray-700">
        <div>
          <span className="text-sm font-semibold text-gray-900 dark:text-white">Active</span>
          <p className="text-xs mt-0.5 text-gray-500 dark:text-gray-400">Toggle off to disable.</p>
        </div>
        <Controller
          name="isActive"
          control={control}
          render={({ field }) => (
            <Toggle
              checked={field.value}
              onChange={(e) => field.onChange(e.target.checked)}
            />
          )}
        />
      </div>

      <div className="flex justify-end gap-3 pt-4 border-t border-gray-200 dark:border-gray-700">
        <Button variant="secondary" type="button" onClick={() => onSaved()}>Cancel</Button>
        <Button
          variant="primary"
          type="submit"
          disabled={isSubmitting}
          className="inline-flex items-center gap-1.5"
        >
          {isSubmitting && <Spinner size="xs" />} Save
        </Button>
      </div>
    </form>
  );
};

// Replace with your real service
declare const yourService: { create: (data: FormData) => Promise<any> };

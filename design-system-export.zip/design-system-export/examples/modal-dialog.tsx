/**
 * Modal dialog — small centered overlay used for short forms or confirmations.
 *
 * Pattern is the SAME shape as the discard-confirm dialog inside slide-overs:
 * fixed inset overlay → centred container with rounded-xl shadow.
 *
 * Use this for:
 *   - Small forms (1–3 fields)
 *   - Single-action confirmations (delete, approve, force-X)
 *   - Anything where a slide-over would be overkill
 */

import React, { useState } from 'react';
import Button from '@/components/atoms/Button/Button';
import Input from '@/components/atoms/Input/Input';
import Spinner from '@/components/atoms/Spinner/Spinner';
import { useToast } from '@/contexts/ToastContext';

interface YourModalProps {
  // The thing being acted on. e.g. { id: 42, name: 'Acme Corp' }
  target: { id: number; name: string };
  onClose: () => void;
  onDone: () => void;
}

export const YourModal: React.FC<YourModalProps> = ({ target, onClose, onDone }) => {
  const { showSuccess, showError } = useToast();
  const [reason, setReason] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!reason.trim()) {
      showError('Reason is required');
      return;
    }
    setSubmitting(true);
    try {
      await yourService.act(target.id, { reason: reason.trim() });
      showSuccess('Done');
      onDone();
    } catch (err: any) {
      showError(err.message || 'Failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/40" onClick={onClose} />

      {/* Dialog */}
      <div className="relative w-full max-w-md mx-4 bg-white dark:bg-gray-900 rounded-lg shadow-xl p-6 animate-fade-in">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Action title</h3>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
              {target.name}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 cursor-pointer"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Body — short form */}
        <div className="mb-5">
          <Input
            label="Reason *"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Why is this happening?"
          />
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-2">
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button
            variant="primary"
            onClick={handleSubmit}
            disabled={!reason.trim() || submitting}
            className="inline-flex items-center gap-1.5"
          >
            {submitting && <Spinner size="xs" />} Confirm
          </Button>
        </div>
      </div>
    </div>
  );
};

// Replace this stub with your actual service
declare const yourService: { act: (id: number, body: any) => Promise<any> };

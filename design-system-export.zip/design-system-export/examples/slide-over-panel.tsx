/**
 * Slide-over panel — the YLIMS canonical right-edge form panel pattern.
 *
 * - Opens with `animate-slide-in-right`, closes with `animate-slide-out-right`.
 * - Backdrop click / X / Cancel show a discard-confirm if there's unsaved work.
 * - Uploaded files are S3-cleaned on discard via fire-and-forget.
 * - Esc key closes (handled by parent or Radix Dialog if you wrap with one).
 *
 * Pair this with the host page's slide-over container:
 *
 *   {panelOpen && (
 *     <div className="fixed inset-0 z-50 flex justify-end">
 *       <div
 *         className={`fixed inset-0 bg-black/40 transition-opacity duration-300 ${
 *           panelClosing ? 'opacity-0' : 'animate-fade-in'
 *         }`}
 *         onClick={() => panelCancelRef.current?.()}
 *       />
 *       <div className={`relative w-full max-w-4xl bg-white dark:bg-gray-900 shadow-xl
 *                         overflow-y-auto ${panelClosing ? 'animate-slide-out-right' : 'animate-slide-in-right'}`}>
 *         <YourPanel onClose={closePanel} cancelRef={panelCancelRef} onSaved={onSaved} />
 *       </div>
 *     </div>
 *   )}
 */

import React, { useState, useEffect } from 'react';
import Button from '@/components/atoms/Button/Button';
import Input from '@/components/atoms/Input/Input';
import Spinner from '@/components/atoms/Spinner/Spinner';
import { useToast } from '@/contexts/ToastContext';

interface YourPanelProps {
  onClose: () => void;
  onSaved: () => void;
  cancelRef?: React.MutableRefObject<(() => void) | null>;
}

export const YourPanel: React.FC<YourPanelProps> = ({ onClose, onSaved, cancelRef }) => {
  const { showSuccess, showError } = useToast();

  // Form state
  const [name, setName] = useState('');
  const [remarks, setRemarks] = useState('');
  const [saving, setSaving] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<{ key: string; fileName: string } | null>(null);
  const [showDiscardConfirm, setShowDiscardConfirm] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  const hasUnsavedWork = (): boolean => !!(name.trim() || remarks.trim() || uploadedFile);

  const handleCancelClick = () => {
    if (hasUnsavedWork()) setShowDiscardConfirm(true);
    else onClose();
  };

  const handleConfirmDiscard = () => {
    setShowDiscardConfirm(false);
    if (uploadedFile) {
      // fire-and-forget S3 cleanup
      yourService.deleteFile(uploadedFile.key).catch(() => {});
    }
    onClose();
  };

  // Expose cancel handler so the parent's backdrop click can call it
  useEffect(() => {
    if (cancelRef) cancelRef.current = handleCancelClick;
    return () => { if (cancelRef) cancelRef.current = null; };
  });

  const scrollToField = (name: string) => {
    setTimeout(() => {
      const el = document.querySelector(`[name="${name}"]`) as HTMLElement;
      if (!el) return;
      const scrollContainer = el.closest('.overflow-y-auto');
      if (scrollContainer) {
        const containerRect = scrollContainer.getBoundingClientRect();
        const elRect = el.getBoundingClientRect();
        scrollContainer.scrollTo({
          top: scrollContainer.scrollTop + (elRect.top - containerRect.top) - containerRect.height / 3,
          behavior: 'smooth',
        });
      }
      setTimeout(() => el.focus(), 300);
    }, 100);
  };

  const handleSave = async () => {
    const errors: Record<string, string> = {};
    if (!name.trim()) errors.name = 'Name is required';
    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      const fieldMap: Record<string, string> = { name: 'panelName' };
      const firstKey = Object.keys(errors)[0];
      showError(errors[firstKey]);
      scrollToField(fieldMap[firstKey]);
      return;
    }

    setFieldErrors({});
    setSaving(true);
    try {
      await yourService.create({ name, remarks, docKey: uploadedFile?.key, docFileName: uploadedFile?.fileName });
      showSuccess('Saved successfully');
      onSaved();
    } catch (err: any) {
      showError(err.message || 'Failed to save');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">New Item</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400">Fill in the details below</p>
        </div>
        <button
          onClick={handleCancelClick}
          className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 cursor-pointer"
        >
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      {/* Form fields */}
      <div className="space-y-4 mb-6">
        <Input
          label="Name *"
          name="panelName"
          value={name}
          onChange={(e) => { setName(e.target.value); setFieldErrors((p) => { const { name, ...r } = p; return r; }); }}
          error={fieldErrors.name}
        />
        <Input
          label="Remarks"
          placeholder="Optional remarks"
          value={remarks}
          onChange={(e) => setRemarks(e.target.value)}
        />
      </div>

      {/* Actions */}
      <div className="flex justify-end gap-3 pt-4 border-t border-gray-200 dark:border-gray-700">
        <Button variant="secondary" onClick={handleCancelClick}>Cancel</Button>
        <Button
          variant="primary"
          onClick={handleSave}
          disabled={saving}
          className="inline-flex items-center gap-1.5"
        >
          {saving && <Spinner size="xs" />} Save
        </Button>
      </div>

      {/* Discard Confirm Dialog */}
      {showDiscardConfirm && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="fixed inset-0 bg-black/40" />
          <div className="relative bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-sm w-full mx-4 p-6">
            <div className="flex items-start gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center shrink-0">
                <svg className="w-5 h-5 text-amber-600 dark:text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
              </div>
              <div>
                <h3 className="text-base font-semibold text-gray-900 dark:text-white">Discard changes?</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Your unsaved work will be lost.</p>
                {uploadedFile && (
                  <p className="text-xs text-gray-400 mt-2">Uploaded document will be removed.</p>
                )}
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="secondary" onClick={() => setShowDiscardConfirm(false)}>Keep editing</Button>
              <Button variant="danger" onClick={handleConfirmDiscard}>Discard</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Replace this stub with your actual service module
declare const yourService: {
  create: (data: any) => Promise<any>;
  deleteFile: (key: string) => Promise<any>;
};

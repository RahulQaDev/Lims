# YLIMS Design System Primer

Comprehensive reference for building components / pages / APIs in the YLIMS style. Sourced from the project's actual conventions, atoms, and CLAUDE.md (architecture rules).

---

## Table of Contents

1. [Brand identity](#1-brand-identity)
2. [Layout primitives](#2-layout-primitives)
3. [Dark mode](#3-dark-mode)
4. [Atom catalog](#4-atom-catalog)
5. [Common UI patterns](#5-common-ui-patterns)
6. [State conventions](#6-state-conventions)
7. [Confirmation dialogs](#7-confirmation-dialogs)
8. [File uploads](#8-file-uploads)
9. [Date / time formatting](#9-date--time-formatting)
10. [Frontend architecture](#10-frontend-architecture)
11. [Backend architecture & API conventions](#11-backend-architecture--api-conventions)
12. [Database conventions](#12-database-conventions)
13. [Mandatory standards (UI)](#13-mandatory-standards-ui)

---

## 1. Brand identity

### Colors

The brand colour is **`#00a6fb`** (primary cyan-blue). Use it for primary buttons, focus rings, active tab borders, brand accents, brand-tinted backgrounds. **Never substitute another blue.**

| Use | Class / value |
|---|---|
| Primary action (button, link emphasis) | `bg-[#00a6fb] text-white` / `hover:bg-[#0095e2]` |
| Primary text accent | `text-[#00a6fb]` |
| Focus ring | `focus:ring-[#00a6fb]` / `focus-visible:outline-[#00a6fb]` |
| Brand-tinted background | `bg-[#00a6fb]/10` (subtle), `bg-[#00a6fb]/20` (hover) |
| Border accent | `border-[#00a6fb]` (active), `border-[#00a6fb]/40` (subtle box) |
| Active tab border | `border-b-2 border-[#00a6fb] text-[#00a6fb]` |

**Semantic palette** — used consistently across the app:

| Semantic | Light | Dark | When |
|---|---|---|---|
| Success / approved / verified | `bg-green-100 text-green-700 border-green-300` | `bg-green-900/30 text-green-300 border-green-700` | Approved status, verified email/phone, success toast, "sample physically received" tick |
| Warning / awaiting / amber | `bg-amber-100 text-amber-700 border-amber-300` | `bg-amber-900/30 text-amber-300 border-amber-700` | "Awaiting TRF", "needs attention" pills, walk-in source badge, sample-only banner |
| Danger / rejected / delete | `bg-red-100 text-red-700 border-red-300` | `bg-red-900/30 text-red-300 border-red-700` | Rejected status, delete confirmation, error toast, file size error |
| Info / pending / neutral-blue | `bg-blue-100 text-blue-700 border-blue-300` | `bg-blue-900/30 text-blue-300 border-blue-700` | "Pending" badge, info notes |
| Surface / muted / disabled | `bg-gray-100 text-gray-700 border-gray-300` | `bg-gray-700 text-gray-300 border-gray-600` | Default badge, secondary text, disabled state |

**Tier badges** (clients have a tier — Diamond / Gold / Silver / Bronze):

| Tier | Light | Dark | Icon |
|---|---|---|---|
| Diamond | `bg-purple-100 text-purple-800` | `bg-purple-900/30 text-purple-300` | `◆` |
| Gold | `bg-yellow-100 text-yellow-800` | `bg-yellow-900/30 text-yellow-300` | `★` |
| Silver | `bg-gray-100 text-gray-700` | `bg-gray-700 text-gray-300` | `✦` |
| Bronze | `bg-orange-100 text-orange-800` | `bg-orange-900/30 text-orange-300` | `●` |

### Typography

- Font: system stack (`-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif`).
- Sizes: `text-xs` (12px) for filter inputs / badge pills · `text-sm` (14px) for body / form labels · `text-base` (16px) for emphasised body · `text-lg` (18px) for section headings inside cards · `text-xl` (20px) for page titles.
- Weight: `font-medium` (500) for labels, `font-semibold` (600) for headings + buttons, `font-bold` (700) for page titles.
- Line height: rely on Tailwind's defaults; for compact rows use `leading-tight`.

### Border-radius

- `rounded-md` (6px) — inputs, buttons, dropdowns
- `rounded-lg` (8px) — cards, panels, banners
- `rounded-xl` (12px) — modals, large dialogs
- `rounded-full` — badges, pills, status chips

### Shadows

- `shadow-xs` — buttons, default cards
- `shadow-sm` — info cards inside panels
- `shadow-xl` — modals, slide-overs, popovers

---

## 2. Layout primitives

### Container widths

- Page header bar: full-width with `px-6 py-4`.
- Slide-over panel: `max-w-4xl` (form panels) or `max-w-md` (small modals).
- Modal dialog: `max-w-md` to `max-w-lg`.

### Spacing rhythm

| Use | Class |
|---|---|
| Section gap | `space-y-6` or `mb-6` |
| Form field gap | `space-y-4` (vertical), `gap-4` (grid) |
| Inline gap inside a row | `gap-2` (default), `gap-3` (looser) |
| Card inner padding | `px-5 py-4` (compact), `p-6` (spacious) |
| Form input padding | `px-3 py-2` (text inputs, filter inputs) |

### Form grid

Two-column form sections use:

```tsx
<div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
  <Input label="Field A" ... />
  <Input label="Field B" ... />
</div>
```

For dynamic-column forms (e.g. four columns on desktop):

```tsx
<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
```

---

## 3. Dark mode

Class-based via `html.dark`. **Every component MUST include dark mode variants.**

The pairing rule:
```tsx
className="bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 border-gray-200 dark:border-gray-700"
```

Common pairs to memorise:

| Light | Dark |
|---|---|
| `bg-white` | `bg-gray-800` (cards) or `bg-gray-900` (page bg, modals, slide-overs) |
| `bg-gray-50` | `bg-gray-700` |
| `bg-gray-100` | `bg-gray-700` |
| `text-gray-900` | `text-white` (or `text-gray-100`) |
| `text-gray-700` | `text-gray-300` |
| `text-gray-500` | `text-gray-400` |
| `border-gray-200` | `border-gray-700` |
| `border-gray-300` | `border-gray-600` |

**Brand and semantic colours** scale via opacity in dark mode:
- Light: `bg-amber-100 text-amber-700`
- Dark: `bg-amber-900/30 text-amber-300`

---

## 4. Atom catalog

All atoms are in `atoms/<Name>/<Name>.tsx`. Below is when to use each + the only convention you must remember per atom.

### Button

```tsx
<Button variant="primary" onClick={...}>Save</Button>
<Button variant="secondary" onClick={...}>Cancel</Button>
<Button variant="danger" onClick={...}>Delete</Button>
<Button variant="outline" onClick={...}>More</Button>
<Button variant="primary" loading>Saving...</Button>  {/* shows inline spinner */}
```

- Sizes: `sm` | `md` (default) | `lg`.
- Always use this atom — never raw `<button>` for actions.
- For icon + text rows: wrap with `inline-flex items-center gap-1.5`.

### Input

```tsx
<Input label="Email" name="email" value={value} onChange={...} error={errors.email?.message} />
```

- `*` marker in label uses default colour (just append ` *` to the label string).
- `error` prop renders a red message below.
- Honours dark mode automatically.

### Select

```tsx
<Select
  label="Courier"
  value={courierId}
  onChange={(e) => setCourierId(e.target.value)}
  placeholder="Select courier"
  options={[{ value: '1', label: 'Blue Dart' }, { value: '2', label: 'FedEx' }]}
  error={fieldErrors.courier}
/>
```

- Custom dropdown trigger (cursor-pointer, portal-rendered).
- Options must be `{ value, label }`.

### Toggle

```tsx
<Toggle
  name="trfReceived"
  checked={trfReceived}
  onChange={(e) => setTrfReceived(e.target.checked)}
/>
```

- Always use this atom for on/off switches. **Don't render raw `<input type="checkbox" role="switch">`.**
- Active colour: `bg-[#00a6fb]`.

### Checkbox

```tsx
<Checkbox checked={agreed} onChange={(e) => setAgreed(e.target.checked)} label="I agree" />
```

### Spinner

Inline indicator. Sizes: `xs` | `sm` | `md` | `lg` | `xl`.

```tsx
<Spinner size="xs" style={{ color: '#00a6fb' }} />        {/* inline next to text */}
<Button loading>Saving...</Button>                       {/* button-internal */}
```

**Never use Spinner for panel-level loading states** — use Skeleton for that.

### Skeleton

```tsx
<Skeleton className="h-4 w-32 rounded" />
<Skeleton className="h-3 rounded" style={{ width: `${80 + i * 20}px` }} />
```

- Mirror the final layout: header band → cards → rows of label/value placeholders → action buttons.
- Use for any panel / card / list that takes >300ms to load.

### Tooltip

Radix-based. Default `side="top"`.

```tsx
<Tooltip content="Print barcode" side="top">
  <button onClick={...}>...</button>
</Tooltip>
```

### Badge

Status chips. Use the semantic palette:

```tsx
<span className="px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider rounded-full
                 bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300">
  Walk-in
</span>
```

### DateInput

```tsx
<DateInput
  value={value}                  // 'yyyy-MM-dd' string
  onChange={(dateStr) => ...}    // emits 'yyyy-MM-dd'
  placeholder="Select date"
  maxDate={new Date()}           // disables future dates
  minDate={fromDate}
  compact                        // smaller variant — matches text-input height in filter rows
  displayFormat="dd MMM yyyy"    // optional display format
/>
```

- Built on `react-day-picker` v9 + `date-fns`.
- Pass `compact` when used inside filter rows / toolbars to match adjacent text-input height.

### TimeInput

```tsx
<TimeInput value="14:35" onChange={(timeStr) => ...} />
```

- 12-hour AM/PM picker. Brand-blue selected state.

### LabLoader

Branded "scientist fetching data" animation. Use for the **first paint** of major data pages, not for general loading.

```tsx
<LabLoader message="Our scientist is fetching your data..." />
```

### Other atoms

- `Label` — wrap form fields.
- `ErrorMessage` — render below a field; bumps space when present.
- `Card` — neutral surface container.
- `Divider` — horizontal rule with consistent margins.
- `Text` — typography wrapper for paragraphs / inline text.
- `Textarea` — multi-line text input, same look as Input.

---

## 5. Common UI patterns

### Page-level: header + tabs + grid

```tsx
<DashboardLayout>
  <div className="flex flex-col h-full">
    {/* Tab bar — counts as pills, only when count > 0 */}
    <div className="flex items-center justify-between mb-4 border-b border-gray-200 dark:border-gray-700">
      <div className="flex gap-1">
        {tabs.map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`px-4 py-2.5 text-sm font-medium transition-colors cursor-pointer ${
              activeTab === tab.key
                ? 'text-[#00a6fb] border-b-2 border-[#00a6fb]'
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
          >
            {tab.label}
            {tab.count > 0 && (
              <span className={`ml-2 px-2 py-0.5 text-xs rounded-full ${
                activeTab === tab.key
                  ? 'bg-[#00a6fb]/10 text-[#00a6fb]'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-500 dark:text-gray-400'
              }`}>{tab.count}</span>
            )}
          </button>
        ))}
      </div>
      {/* Optional summary chip on the far right */}
    </div>

    <div className="flex-1 overflow-hidden">
      {activeTab === 'pending' && <YourGridComponent ... />}
    </div>
  </div>
</DashboardLayout>
```

### Slide-over panel (right-edge form panel)

See `examples/slide-over-panel.tsx` for the full pattern. Key parts:

- Fixed `inset-0 z-50 flex justify-end`.
- Backdrop: `bg-black/40` with `animate-fade-in` / `animate-fade-out`.
- Panel: `max-w-4xl` (form) or `max-w-md` (small modal), `animate-slide-in-right` on open / `animate-slide-out-right` on close.
- Click backdrop / X / Cancel → if unsaved work, show discard-confirm dialog; else close immediately.
- Cleanup uploaded files via fire-and-forget `deleteReceptionDoc(key)` if user discards.

### Modal dialog (centered overlay)

See `examples/modal-dialog.tsx`. Key parts:

- `fixed inset-0 z-[60] flex items-center justify-center`.
- Backdrop `bg-black/40`, click closes (or shows discard-confirm).
- Dialog: `max-w-md` (small) to `max-w-lg` (medium). `bg-white dark:bg-gray-900 rounded-lg shadow-xl p-6 animate-fade-in`.
- Action buttons right-aligned at bottom: Secondary (Cancel) + Primary (Save / Confirm).

### Form with validation

See `examples/form-with-validation.tsx`. Pattern:

- React Hook Form + Zod schema.
- On submit: collect all errors → show toast with the first one → auto-scroll to first invalid field → auto-focus.
- Inline error message below the field via the atom's `error` prop.

---

## 6. State conventions

### Loading states

| Where | What to use |
|---|---|
| Page first-paint (major data fetch) | `<LabLoader />` (branded scientist) OR skeleton mirroring layout |
| Panel / slide-over body | Skeleton mirroring panel structure |
| List / grid row body | Skeleton rows with same column widths |
| Inline text update | `<Spinner size="xs" />` next to text |
| Save / submit button | `<Button loading>...</Button>` (atom internal spinner) |
| Search debounce | `<Spinner size="xs" />` absolutely positioned in the search input |
| File upload progress | `<Spinner size="xs" />` inside the upload area |

### Error states

- **Form validation** → toast (first error) + inline error message + auto-scroll + auto-focus.
- **API error** → toast with friendly message extracted from `extractErrorMessage(err)`.
- **Server 500 / 502 / 503** → friendly toast: *"The server is temporarily unavailable. Please try again in a few moments."* (don't show raw axios message).
- **Network error / timeout** → *"The request took too long. Please try again."*.

### Success states

- After a save / submit → toast `<resource> saved successfully` / `Walk-in sample recorded — DPK…` etc.
- After a destructive action → toast confirming the count, e.g. `5 TRFs sent for activation`.

---

## 7. Confirmation dialogs

Two distinct patterns.

### 7a. Discard-changes confirm (when closing an unsaved form)

```tsx
{showDiscardConfirm && (
  <div className="fixed inset-0 z-[60] flex items-center justify-center">
    <div className="fixed inset-0 bg-black/40" />
    <div className="relative bg-white dark:bg-gray-800 rounded-xl shadow-xl max-w-sm w-full mx-4 p-6">
      <div className="flex items-start gap-3 mb-4">
        <div className="w-10 h-10 rounded-full bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center shrink-0">
          <svg className="w-5 h-5 text-amber-600 dark:text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
        </div>
        <div>
          <h3 className="text-base font-semibold text-gray-900 dark:text-white">Discard changes?</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Your unsaved work will be lost.</p>
          {uploadedFile && (
            <p className="text-xs text-gray-400 mt-2 inline-flex items-center gap-1">
              <DocumentIcon className="w-3 h-3" />
              Uploaded document will be removed
            </p>
          )}
        </div>
      </div>
      <div className="flex justify-end gap-2">
        <Button variant="secondary" onClick={() => setShowDiscardConfirm(false)}>Keep editing</Button>
        <Button variant="danger" onClick={handleConfirmDiscard}>Discard</Button>
      </div>
    </div>
  </div>
)}
```

### 7b. Destructive-action confirm (delete, cancel, force-something)

Same shape but red-coloured icon and "Delete" / "Cancel batch" / etc. as the danger button. Add a remarks/reason `Textarea` if the action requires capturing a why.

```tsx
<div className="w-10 h-10 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
  {/* trash / x-octagon / similar icon, text-red-600 */}
</div>
<h3 ...>Delete this PO?</h3>
<p ...>This cannot be undone. {childCount} batch(es) will be detached.</p>
{requiresReason && (
  <Textarea label="Reason *" value={reason} onChange={...} />
)}
<Button variant="danger" disabled={requiresReason && !reason.trim()} onClick={handleConfirm}>
  Delete
</Button>
```

---

## 8. File uploads

Standard upload area pattern (PDF / JPG / PNG, 10MB max):

```tsx
{uploadedFile ? (
  <div className="flex items-center gap-3 px-3 py-2.5 border border-green-300 dark:border-green-700 bg-green-50 dark:bg-green-900/20 rounded-lg">
    <DocumentIcon className="w-4 h-4 text-green-600 dark:text-green-400" />
    <span className="text-sm text-green-800 dark:text-green-200 truncate flex-1 font-medium">
      {uploadedFile.fileName}
    </span>
    <button onClick={openInNewTab}>View</button>
    <button onClick={removeFile} className="text-red-600 dark:text-red-400">Remove</button>
  </div>
) : (
  <label className={`flex items-center justify-center gap-2 px-3 py-2.5 border border-dashed rounded-lg ${
    uploading
      ? 'border-blue-300 bg-blue-50/50 dark:border-blue-700 dark:bg-blue-900/10'
      : 'border-gray-300 dark:border-gray-600 hover:border-[#00a6fb] dark:hover:border-[#00a6fb] cursor-pointer'
  }`}>
    {uploading ? (
      <><Spinner size="xs" style={{ color: '#00a6fb' }} /><span className="text-xs text-[#00a6fb]">Uploading...</span></>
    ) : (
      <span className="text-xs text-gray-500 dark:text-gray-400">
        Click to upload <span className="text-gray-400 dark:text-gray-500">(PDF, JPG, PNG — max 10MB)</span>
      </span>
    )}
    <input type="file" name="..." accept=".pdf,.jpg,.jpeg,.png" disabled={uploading} className="hidden"
      onChange={async (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png'];
        if (!allowedTypes.includes(file.type)) {
          showError(`Only PDF, JPG, and PNG files are allowed — "${file.name}"`);
          e.target.value = ''; return;
        }
        if (file.size > 10 * 1024 * 1024) {
          showError(`File size must not exceed 10MB — "${file.name}"`);
          e.target.value = ''; return;
        }
        setUploading(true);
        try {
          const res = await yourService.upload(file);
          if (res.success) setUploadedFile(res.data);
        } catch (err) { showError(err.message); }
        finally { setUploading(false); e.target.value = ''; }
      }}
    />
  </label>
)}
```

**Key conventions:**
- File type allowlist enforced both via `accept` attribute and JS MIME check.
- Error toasts include the filename in quotes.
- Uploaded state: green border, doc icon, View + Remove buttons.
- Uploading state: blue dashed border with inline spinner.

---

## 9. Date / time formatting

| Format | Use | Helper |
|---|---|---|
| `dd MMM yyyy` (`28 Apr 2026`) | All date-only displays — grids, previews, list cells. | `formatDate(value)` from `utils/date.ts` |
| `dd MMM yyyy, HH:mm` (`28 Apr 2026, 14:35`) | Date + time, 24-hour. Default for audit logs, timestamps. | `formatDateTime(value)` |
| `dd MMM yyyy, hh:mm a` (`28 Apr 2026, 02:35 PM`) | Date + time, 12-hour AM/PM. Used in some pickers and UI where AM/PM is clearer. | Inline `format(date, 'dd MMM yyyy, hh:mm a')` |
| `dd/MM/yyyy` | DateInput display format only. Not for read-only displays. | DateInput's default `displayFormat` prop |

**Timezone:** the app runs on Indian Standard Time. Backend Node process must be `process.env.TZ = 'Asia/Kolkata'` and mssql must be `useUTC: false` if using SQL Server. Frontend trusts the backend's ISO strings — don't apply manual timezone math anywhere in the UI.

---

## 10. Frontend architecture

### Atomic Design

```
atoms/        — single-purpose UI primitives (Button, Input, Spinner, …)
molecules/    — small composed UI (FormField, Header, DataTable cell renderers)
organisms/    — complex composed UI (DashboardLayout, ReusableDataGrid, slide-over content)
pages/        — route-level components, one per page
```

Prefer composition over configuration. A new feature usually = one new page + 1–2 new organisms + reuse of atoms.

### State

- No Redux / Zustand / MobX. Use React Context for global state.
- `useAuth()` from `AuthContext` — current user + permissions.
- `useToast()` from `ToastContext` — `showSuccess` / `showError` / `showInfo`.
- Local component state with `useState` / `useReducer`.
- Data fetching via Axios in service modules (no fetch / SWR / React Query).

### Forms

- React Hook Form for state.
- Zod (v4) for schemas — `zodResolver(schema)` to wire RHF.
- Always use the `Input` / `Select` / `Toggle` / `Textarea` atoms inside `Controller`, never raw HTML elements.
- On submit fail: toast first error + auto-scroll-to-first-invalid + auto-focus.

### Services

`services/api/<module>Service.ts` — pure function exports calling a shared `apiClient` (Axios instance with interceptors for auth token + 401 redirect).

```tsx
// frontend/src/services/api/<module>Service.ts
import apiClient from './apiClient';
import { extractErrorMessage } from '../../utils/apiErrorHandler';

const yourService = {
  list: async (params): Promise<ListResponse> => {
    try {
      const res = await apiClient.get(`/api/your-module?${new URLSearchParams(params)}`);
      return res.data;
    } catch (err) { throw new Error(extractErrorMessage(err, 'Failed to fetch')); }
  },
  create: async (data): Promise<CreateResponse> => {
    try {
      const res = await apiClient.post('/api/your-module', data);
      return res.data;
    } catch (err) { throw new Error(extractErrorMessage(err, 'Failed to create')); }
  },
};

export default yourService;
```

### Path aliases

`@/*` → `src/*` via Vite `resolve.alias` and TypeScript paths.

---

## 11. Backend architecture & API conventions

> Source: project root `CLAUDE.md`. Reproduced here so the bundle is self-contained.

### Stack

- Node.js 22+
- Express + TypeScript
- Microsoft SQL Server 2019+ (or any SQL DB — adapt the repository layer)
- JWT auth
- Zod 3.x for validation
- mssql library for DB access (with `useUTC: false` if your server is in IST)

### Four-layer module structure

Every backend module lives in `backend/src/api/<module>/` with:

```
<module>.routes.ts        — Express route definitions + middleware (validation, permission, rate limit)
<module>.controller.ts    — Class-based controllers, methods bound in routes
<module>.service.ts       — Business logic
<module>.repository.ts    — SQL queries (parameterized)
<module>.types.ts         — TypeScript interfaces (request, response, internal)
<module>.validation.ts    — Zod schemas
<module>.swagger.ts       — OpenAPI docs (optional)
```

### Request flow

```
HTTP → Helmet → CORS → Body Parser → Logger
  → authenticateToken → attachPermissions
  → hasPermission(...) / rateLimit(...) / validateRequest(schema)
  → Controller method → Service method → Repository method → DB
  ← JSON response { success, data, message } or { success: false, error: {...} }
```

### Route definition example

```ts
// <module>.routes.ts
import { Router } from 'express';
import { YourController } from './your.controller';
import { validateRequest } from '../../middleware/validation';
import { authenticateToken } from '../../middleware/auth.middleware';
import { hasPermission, Permission, attachPermissions, rateLimit } from '../../common/middleware/authorization.middleware';
import { createSchema, listSchema } from './your.validation';

const router = Router();
const controller = new YourController();
router.use(authenticateToken as any);
router.use(attachPermissions());

router.get(
  '/',
  validateRequest(listSchema),
  hasPermission(Permission.VIEW_X),
  rateLimit(100, 60000),
  controller.list.bind(controller)
);

router.post(
  '/',
  validateRequest(createSchema),
  hasPermission(Permission.CREATE_X),
  rateLimit(20, 60000),
  controller.create.bind(controller)
);

export { router as yourRoutes };
```

### Controller example

```ts
// <module>.controller.ts
export class YourController {
  private readonly service: YourService;
  constructor() { this.service = new YourService(); }

  async list(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      const filters = {
        page: parseInt(req.query.page as string) || 1,
        pageSize: parseInt(req.query.pageSize as string) || 20,
        search: (req.query.search as string) || '',
        currentLocationId: req.user!.locationId, // location-scoped per project convention
      };
      const result = await this.service.list(filters);
      res.status(200).json({ success: true, data: result.data, meta: result.meta });
    } catch (err: any) { next(err); }
  }
}
```

### Service example

```ts
// <module>.service.ts
export class YourService {
  private readonly repository: YourRepository;
  constructor() { this.repository = new YourRepository(); }

  async list(filters): Promise<{ data; meta }> {
    const result = await this.repository.list(filters);
    return {
      data: result.data,
      meta: { totalRecords: result.totalRecords, currentPage: filters.page, pageSize: filters.pageSize },
    };
  }
}
```

### Repository example (parameterized SQL)

```ts
// <module>.repository.ts
import sql from 'mssql';
import { executeQuery } from '@/config/sqlserver.config';

export class YourRepository {
  async list(filters): Promise<{ data; totalRecords: number }> {
    const conditions: string[] = ['(t.is_deleted IS NULL OR t.is_deleted = 0)'];
    const inputs: Array<{ name: string; type: any; value: any }> = [];

    if (filters.currentLocationId) {
      conditions.push('t.location_id = @locationId');
      inputs.push({ name: 'locationId', type: sql.Int, value: filters.currentLocationId });
    }
    if (filters.search?.trim()) {
      conditions.push('t.name LIKE @search');
      inputs.push({ name: 'search', type: sql.VarChar, value: `%${filters.search.trim()}%` });
    }

    const whereClause = conditions.join(' AND ');
    const offset = (filters.page - 1) * filters.pageSize;

    const [countResult, dataResult] = await Promise.all([
      executeQuery(`SELECT COUNT(*) AS total FROM your_table t WHERE ${whereClause}`, inputs),
      executeQuery(
        `SELECT * FROM your_table t WHERE ${whereClause}
         ORDER BY t.created_date DESC
         OFFSET @offset ROWS FETCH NEXT @pageSize ROWS ONLY`,
        [...inputs,
         { name: 'offset', type: sql.Int, value: offset },
         { name: 'pageSize', type: sql.Int, value: filters.pageSize }]
      ),
    ]);

    return { data: dataResult.recordset, totalRecords: countResult.recordset[0]?.total || 0 };
  }
}
```

### Response envelope

**Success**:

```json
{ "success": true, "data": { ... }, "meta": { "totalRecords": 42, "currentPage": 1, "pageSize": 20 }, "message": "Retrieved" }
```

**Failure** (caught by error middleware):

```json
{ "success": false, "error": { "code": "BAD_REQUEST", "message": "Email is required" } }
```

The Axios interceptor on the frontend extracts `error.message` automatically — make sure your Express error middleware sticks to this shape.

### Auth & permissions

- `authenticateToken` decodes the JWT and attaches `req.user = { userId, locationId, role, ... }`.
- `attachPermissions()` maps role → permission set on `req.user`.
- `hasPermission(Permission.X, Permission.Y)` passes if user has **any** of the listed permissions.
- For per-row location checks, controllers do `if (!isAdmin) await canUserAccess(...)` before the service call.

### Validation (Zod)

```ts
// <module>.validation.ts
import { z } from 'zod';

export const createSchema = z.object({
  body: z.object({
    name: z.string().min(1).max(200),
    email: z.string().email(),
    locationId: z.number().int().positive(),
  }),
});

export const listSchema = z.object({
  query: z.object({
    page: z.coerce.number().int().positive().optional(),
    pageSize: z.coerce.number().int().positive().max(100).optional(),
    search: z.string().optional(),
  }),
});
```

The `validateRequest(schema)` middleware throws a 400 with the first Zod error if the request fails.

### SQL conventions

- **Always parameterized.** Never string-interpolate user input into SQL.
- **Soft delete** — every table has `is_deleted` BIT default 0. Lists filter `is_deleted IS NULL OR is_deleted = 0`.
- **Audit columns** — `created_by`, `created_date`, `modified_by`, `modified_date` on every business table.
- **Connection pool** — min 5, max 20, 60s request timeout.

---

## 12. Database conventions

### Naming

- Entities: `{entity}_master`, `{entity}_details`.
- Mappings: `map_{a}_{b}`.
- Stored procedures: `Prc_Get_{Entity}`, `Prc_Insert_{Entity}`, `Prc_Update_{Entity}`.

### Patterns

- Soft deletes via `is_deleted` BIT.
- XML storage for complex nested data (e.g. `contacts_xml` in `client_master`) where rows-per-row would explode the schema.
- Temp tables with GUID for batch operations.
- Atomic counters (e.g. `app_setting_barcode`) wrapped in `WITH (UPDLOCK, HOLDLOCK)`.

### Migration / schema-change process

- **Never** auto-execute SQL via the app or migration tools.
- Authoring: every DB change is captured in a markdown doc under `backend/docs/database/` with:
  - The full `IF NOT EXISTS`-guarded ALTER / CREATE.
  - A "Why" paragraph.
  - A verification SELECT.
  - A rollback block (DO NOT RUN unless undoing).
- DBA / lead runs the SQL manually in SSMS, in order. App code releases pair with the migration.

---

## 13. Mandatory standards (UI)

These are non-negotiable in the YLIMS UI. Apply them to every component / page Claude builds.

1. **`*` for required fields uses default label colour** — never `text-red-500`.
2. **Auto-scroll + auto-focus on first invalid field** when a form fails validation.
3. **Toast + inline error message** combination — both must fire, not one or the other.
4. **Spinner inside Save/Submit buttons** while the request is in flight; button disabled during.
5. **Skeleton-first loading** for any layout that would jump on data arrival; reserve Spinner for inline indicators.
6. **OTP / verification fields reset** when the user changes the underlying value (e.g. email or phone) — the verify badge clears, OTP is invalidated.
7. **Search-highlighting in grids** — when global search is active, matched substrings are wrapped in `<mark>` (or a brand-blue background span).
8. **"Same as company address" toggles** auto-fill all address fields when ticked; clear them when un-ticked.
9. **Dark mode** — every new component must include dark variants. Run a manual `html.dark` pass before merging.
10. **React hooks rules** — never call hooks conditionally; consolidate effects rather than adding more.

---

## End of primer

If a pattern you need isn't here, follow the closest example and ask the user a clarifying question rather than improvising. The goal is consistency: a YLIMS user should be able to land on a new page and feel they're in the same app.

# Tailwind v4 Setup — YLIMS Tokens

YLIMS uses **Tailwind CSS v4** with the CSS-first configuration model (no `tailwind.config.js`). All tokens live in the entry CSS file via `@theme`.

## Project setup

1. Install:

```bash
npm install tailwindcss@^4 @tailwindcss/vite
```

2. Vite plugin:

```ts
// vite.config.ts
import tailwindcss from '@tailwindcss/vite';
export default {
  plugins: [tailwindcss()],
};
```

3. Entry CSS — paste the block below into `src/index.css` (or wherever you import global styles):

```css
@import "tailwindcss";

/* ─── YLIMS Theme Tokens ─────────────────────────────────────────── */
@theme {
  /* Brand — primary cyan-blue */
  --color-primary-50:  #e6f6ff;
  --color-primary-100: #b3e3ff;
  --color-primary-200: #80cfff;
  --color-primary-300: #4dbcff;
  --color-primary-400: #1aa9ff;
  --color-primary-500: #00a6fb;   /* canonical brand */
  --color-primary-600: #0095e2;
  --color-primary-700: #0077b3;
  --color-primary-800: #005983;
  --color-primary-900: #003b54;

  /* Animations used by slide-overs, dialogs, popovers */
  --animate-fade-in:        fade-in 0.2s ease-out;
  --animate-fade-out:       fade-out 0.2s ease-in;
  --animate-slide-in-right: slide-in-right 0.3s ease-out;
  --animate-slide-out-right: slide-out-right 0.3s ease-in;
}

@keyframes fade-in        { from { opacity: 0; } to { opacity: 1; } }
@keyframes fade-out       { from { opacity: 1; } to { opacity: 0; } }
@keyframes slide-in-right { from { transform: translateX(100%); } to { transform: translateX(0); } }
@keyframes slide-out-right { from { transform: translateX(0); } to { transform: translateX(100%); } }

/* ─── Class-based dark mode (html.dark) ─────────────────────────── */
@custom-variant dark (&:where(.dark, .dark *));
```

4. Mark dark mode on the `<html>` element:

```html
<html class="dark">  <!-- or toggle via JS -->
```

## Brand-color usage

You can use the brand either as `bg-primary-500` etc. (via the `--color-primary-*` tokens above) **or** as the literal arbitrary value `bg-[#00a6fb]`. The YLIMS codebase uses the literal value most often because it reads at a glance. Both work.

```tsx
<button className="bg-[#00a6fb] hover:bg-[#0095e2]">Save</button>
{/* OR */}
<button className="bg-primary-500 hover:bg-primary-600">Save</button>
```

## Custom variants used in atoms

The atoms reference the standard Tailwind utility classes only — no custom variants beyond `dark:`. You should not need anything else.

## What you do NOT need

- No `tailwind.config.js` file.
- No `darkMode: 'class'` in JS config — handled by the `@custom-variant dark` line above.
- No `content: [...]` glob — Tailwind v4 auto-detects via your bundler.
- No PostCSS plugin — the Vite plugin handles compilation.

## Preflight (Tailwind's CSS reset)

Tailwind v4 includes its preflight reset by default. The atoms assume this is in place — `<button>` has no default background, `<input>` has no default border, etc. If you import `@import "tailwindcss";` you're fine.

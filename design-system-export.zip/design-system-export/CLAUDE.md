# Claude Instructions — YLIMS Design System

> **Purpose:** This file tells Claude how to build new UI in the YLIMS visual / interaction style. Hand it to Claude as a system prompt or top-level instruction file alongside the rest of this folder.

## You are building UI in the YLIMS style

The user's reference codebase is YLIMS — a React 19 + Tailwind v4 app for a chemistry lab. This folder contains:

- 18 atom components (`atoms/<Name>/<Name>.tsx`) — **use them as-is**, do not reinvent.
- Utilities (`utils/`) — `cn`, `classNames`, `date.ts`, `formatters.ts`.
- A primer (`design-system-primer.md`) describing colours, layout, state, validation, dark mode, file upload, etc.
- Tailwind v4 setup (`tailwind-config.md`).
- Example molecule patterns (`examples/`).

## Hard rules

1. **Never invent a new Button / Input / Select / Toggle / Spinner / Skeleton / Tooltip / Badge / Card / Divider / DateInput / TimeInput.** Import them from `@/components/atoms/<Name>/<Name>` (or whatever path the host project uses).
2. **Brand colour is `#00a6fb`.** Use it for primary actions, focus rings, brand accents. Never substitute another blue.
3. **Dark mode is class-based** (`html.dark`). Every new component MUST have dark mode variants — no exceptions. If a colour appears in light mode, its dark mode pair must appear in the same className.
4. **Required-field marker is `*` in the default label colour.** Do **not** use `<span className="text-red-500">*</span>` — that has been explicitly rejected as inconsistent.
5. **Loading states use `Skeleton`, not `Spinner`,** for any block where layout would jump on first paint (panels, lists, cards). `Spinner` is reserved for inline indicators (search-as-you-type, save buttons, file upload progress).
6. **Validation pattern**: toast error + inline error message + auto-scroll to the first invalid field + auto-focus where applicable. Don't drop any of these.
7. **File upload errors must include the filename**: `File size must not exceed 10MB — "report.pdf"`. Not the bare message.
8. **Toggle component is the canonical on/off switch.** Don't render raw `<input type="checkbox" role="switch">` — use the `Toggle` atom.
9. **Date / datetime display format**:
   - Date-only: `dd MMM yyyy` (`28 Apr 2026`) via `formatDate`.
   - Date + time 24-hour: `dd MMM yyyy, HH:mm` (`28 Apr 2026, 14:35`) via `formatDateTime`.
   - Date + time 12-hour: `dd MMM yyyy, hh:mm a` (`28 Apr 2026, 02:35 PM`) — inline `format(date, 'dd MMM yyyy, hh:mm a')`.
10. **Spacing/typography**: follow the primer's "Layout primitives" and "Typography" sections. Don't introduce ad-hoc font sizes.
11. **Comments**: write code comments only when the *why* is non-obvious. Don't write multi-line docstrings for trivial atoms.
12. **No emojis** in code or UI unless the user explicitly asks.

## Decision rubric — when the user asks for something

| Request | What to build |
|---|---|
| "Add a form" | RHF + Zod, atoms only, scroll-to-error, toast on submit fail. |
| "Add a slide-over panel" | See `examples/slide-over-panel.tsx`. Use the same animation classes (`animate-slide-in-right`), backdrop, close-on-backdrop, discard-confirm-if-unsaved pattern. |
| "Add a modal" | See `examples/modal-dialog.tsx`. |
| "Add a list page" | Tabs at top (each with count pill, only when > 0), grid in middle, custom filter dropdown rightmost, search at top of grid. |
| "Add a loader" | Skeleton mirroring final layout (header + cards + rows of label/value placeholders). Use the existing `Skeleton` atom. |
| "Add a status badge" | Use the `Badge` atom. Colour scheme: amber for "needs attention", red for "error/rejected", green for "approved/active", blue for "informational/in-progress", gray for "draft/inactive". |
| "Add a toast" | Use the existing `useToast()` hook pattern from the host app (or whatever toast library it uses). Don't reinvent. |
| "Add a tooltip" | Use the `Tooltip` atom (Radix-based). Default `side="top"`. |

## When in doubt

1. Read `design-system-primer.md` (the master reference).
2. Read the closest example in `examples/`.
3. Read the actual atom source you're using (`atoms/<Name>/<Name>.tsx`).
4. If still ambiguous, ask the user a single clarifying question before building.

## What to AVOID

- ❌ Importing UI libraries (shadcn, MUI, Chakra, antd) — atoms here are purpose-built. Adding another lib leads to visual mismatch.
- ❌ `Math.random()` for IDs — use `crypto.randomUUID()`.
- ❌ `setTimeout` for sequencing async — use `await`.
- ❌ Pixel values like `style={{ width: 200 }}` — use Tailwind classes.
- ❌ Generic blue Tailwind shades when the brand `#00a6fb` is more appropriate.
- ❌ Adding `console.log` in committed code (only for active debugging).
- ❌ Skipping the dark mode variants on any new component.
